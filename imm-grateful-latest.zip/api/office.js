const dbx = require("./_db");

function homeId(user) {
  if (!user) return null;
  return user.householdId || (user.role === "limb" ? null : user.id);
}

module.exports = async function handler(req, res) {
  if (req.method === "OPTIONS") return dbx.send(res, 204, {});
  const body = ["POST", "PUT"].includes(req.method) ? await dbx.readBody(req) : {};
  req.body = body;
  const { db, user } = await dbx.requireUser(req);
  if (!user) return dbx.send(res, 401, { ok: false, error: "Sign in required" });

  if (!db.office || typeof db.office !== "object") db.office = { homes: {}, updatedAt: null };
  const hid = homeId(user);
  if (!hid) return dbx.send(res, 403, { ok: false, error: "Join a parent home with their invite code first" });

  if (req.method === "GET" || body.action === "get") {
    const home = db.office.homes[hid] || null;
    const household = db.households[hid] || null;
    return dbx.send(res, 200, {
      ok: true,
      householdId: hid,
      home,
      shared: (home && home.shared) || (household && household.shared) || null,
      members: (household && household.members) || [],
    });
  }

  if (user.developer && body.action === "admin") {
    const homes = Object.keys(db.office.homes || {}).map((id) => ({
      householdId: id,
      updatedAt: db.office.homes[id].updatedAt,
      villagers: ((db.office.homes[id].shared && db.office.homes[id].shared.village) || []).length,
      logs: ((db.office.homes[id].shared && db.office.homes[id].shared.logs) || []).length,
    }));
    return dbx.send(res, 200, {
      ok: true,
      sessions: (db.sessions || []).filter((s) => s.exp > Date.now()).length,
      logins: (db.logins || []).slice(0, 40),
      homes,
      store: dbx.kind(),
    });
  }

  const shared = body.shared || (body.household && body.household.shared) || null;
  const prev = db.office.homes[hid] || { shared: null };
  db.office.homes[hid] = {
    householdId: hid,
    updatedAt: new Date().toISOString(),
    updatedBy: user.id,
    shared: shared || prev.shared,
    inviteCode: user.role === "limb" ? user.inviteCode : (body.inviteCode || user.inviteCode || null),
  };
  if (shared) {
    db.households[hid] = Object.assign(db.households[hid] || {}, { shared });
  }
  db.office.updatedAt = db.office.homes[hid].updatedAt;
  await dbx.save(db);
  return dbx.send(res, 200, { ok: true, householdId: hid, updatedAt: db.office.updatedAt });
};
